# Hub building concepts — PixelLab

Ten new decorative building concepts, distributed across the existing eight hub levels. Native transparent sprite canvases range from 64×64 to 256×192. This is an art/design set for future placement; it does not introduce new gameplay services, unlock costs, collisions, or loader registrations.

Redesigned with PixelLab Pro on 2026-09-07 using `public/sprites/companions/burt-house.png` as the direct style reference. PixelLab palette reduction enforces pure black and white without dithering. The buildings inherit Burt's three-quarter top-down view, chunky white roofs and walls, deep black entrances, uneven salvage-built silhouettes, and sparse wear. They should feel inhabited rather than diagrammatic. Introduce them cumulatively so each hub level retains earlier structures.

| Level | Building | Native canvas | Suggested placement and activity |
| --- | --- | --- | --- |
| 1 | Service Shack | 64×64 | Beside the arrival lane, with a small canopy for the emergency repair droid. |
| 2 | Courier Cabin | 96×64 | Near the contract terminal, serving as a lived-in parcel office and courier stop. |
| 3 | Scrap Workshop | 96×96 | On the salvage side, with a wide workshop door and an exterior scrap lean-to. |
| 3 | Smelter House | 128×96 | Behind the salvage forge, combining a furnace workshop with a crooked utility room. |
| 4 | Signal Loft | 96×128 | On the outer rim near the signal array, giving its keeper a tall lookout and home. |
| 5 | Repair Barn | 160×128 | Beside the maintenance wing, with a large dark bay and attached tool sheds. |
| 6 | Fuel Keeper | 128×128 | Along a quieter approach, combining a small dwelling with two protected fuel tanks. |
| 6 | Freight Lodge | 192×128 | Near the gantries, with loading doors, joined cargo sheds, and a staffed side office. |
| 7 | Habitat Row | 192×192 | On the calmer side of the traffic grid, forming a small neighborhood of connected homes. |
| 8 | Watchmaker Hall | 256×192 | Across from the phase station, acting as a late-game guild hall and observatory landmark. |

## Placement principles

Keep the central phase station, existing facility entrances, and travel lanes open. Put larger structures toward the perimeter, with smaller service buildings filling gaps. Treat footprints as the occupied sprite silhouette rather than the full canvas. Keep all sprites at native size initially; decide world scale in a scene review before adding collisions.

Ambient buildings should render dimmer than the player and interactive stations. Use runtime tint on the monochrome artwork; do not bake cyan glow into every roof. Small traffic, lights, or repair activity can communicate restoration progress later.

## Integration notes

Keep these concept files outside the runtime sprite loader until placed. When integrating, use a dedicated building atlas or append a coherent group after existing gameplay/background registrations, per the asset skill. Use the existing hub restoration tier switch and batched systems for any activity. Review draw calls in the same hub state before and after integration.

## Provenance

Generation prompts, native dimensions, level assignments, selected variants, and PixelLab job IDs are in [manifest.json](manifest.json). The rejected overhead set remains in `source` and `sprites` for comparison. Burt-inspired source images are in `source-v2`; final palette-constrained concepts are in `sprites-v2`.

## Review

All ten images were inspected on a dark background at native size. Dimensions and monochrome palettes are checked by `build-preview.py`. This is a concept pack; scene placement, tint, collision footprints, and draw-call verification remain for integration.

Open [the gallery](index.html) for native/2×/3× previews and a cumulative hub-level filter, or [the contact sheet](contact-sheet.png) for the full roster.
