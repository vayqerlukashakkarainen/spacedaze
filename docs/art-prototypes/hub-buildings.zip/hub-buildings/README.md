# Hub building concepts — PixelLab

Ten new decorative building concepts, distributed across the existing eight hub levels. Native transparent sprite canvases range from 64×64 to 256×192. This is an art/design set for future placement; it does not introduce new gameplay services, unlock costs, collisions, or loader registrations.

Generated with PixelLab Pixen, Pixflux, and Pro on 2026-09-07. Selected Pro variants use the existing phase station as a style reference. PixelLab palette reduction enforces pure black and white without dithering. Art direction: overhead mechanical roof plans, black structural masses, white pixel contours, transparent exterior, no cast shadows or baked-in lighting. Introduce the buildings cumulatively so each hub level retains earlier structures.

| Level | Building | Native canvas | Suggested placement and activity |
| --- | --- | --- | --- |
| 1 | Service Kiosk | 64×64 | Beside the arrival lane. A small service light and repair-droid stopping point make level 1 feel inhabited. |
| 2 | Courier Depot | 96×64 | Near the contract terminal. Couriers can pause at the open docking recess before heading out. |
| 3 | Scrap Sorter | 96×96 | On the salvage side of the hub. Haulers can deliver scrap to the conveyor mouth. |
| 3 | Smelter Annex | 128×96 | Behind the salvage forge. A heavier industrial silhouette builds out the manufacturing district. |
| 4 | Listening Post | 96×128 | On the outer rim near the signal array. Its tall footprint breaks up the round facilities. |
| 5 | Repair Drydock | 160×128 | Beside the maintenance wing. The open slot gives repair ships a clear place to work. |
| 6 | Fuel Farm | 128×128 | Along a quieter docking approach. Tank clusters and small pipes provide mid-sized infill. |
| 6 | Freight Terminal | 192×128 | At the perimeter next to level 6 gantries. Three docking fingers provide obvious traffic destinations. |
| 7 | Habitat Cluster | 192×192 | On the calmer side of the traffic grid. This gives the growing hub a residential district. |
| 8 | Observatory Crown | 256×192 | Across from the phase station, behind the outer traffic lane. A late-game landmark that balances the hub without replacing its central station. |

## Placement principles

Keep the central phase station, existing facility entrances, and travel lanes open. Put larger structures toward the perimeter, with smaller service buildings filling gaps. Treat footprints as the occupied sprite silhouette rather than the full canvas. Keep all sprites at native size initially; decide world scale in a scene review before adding collisions.

Ambient buildings should render dimmer than the player and interactive stations. Use runtime tint on the monochrome artwork; do not bake cyan glow into every roof. Small traffic, lights, or repair activity can communicate restoration progress later.

## Integration notes

Keep these concept files outside the runtime sprite loader until placed. When integrating, use a dedicated building atlas or append a coherent group after existing gameplay/background registrations, per the asset skill. Use the existing hub restoration tier switch and batched systems for any activity. Review draw calls in the same hub state before and after integration.

## Provenance

Generation prompts, native dimensions, level assignments, and PixelLab job IDs are in [manifest.json](manifest.json). Individual source images are retained in the source directory; final palette-constrained concepts are in sprites.

## Review

All ten images were inspected on a dark background at native size. Dimensions and monochrome palettes are checked by `build-preview.py`. This is a concept pack; scene placement, tint, collision footprints, and draw-call verification remain for integration.

Open [the gallery](index.html) for native/2×/3× previews and a cumulative hub-level filter, or [the contact sheet](contact-sheet.png) for the full roster.
